package com.example.jesenia_roberts_proj2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    Button signInButton;
    Button signUpButton;

    EditText new_username;
    EditText new_password;
    EditText existing_username;
    EditText existing_password;

    AccountDatabaseHelper accountDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        existing_username = (EditText) findViewById(R.id.username1);
        existing_password = (EditText) findViewById(R.id.password1);
        new_username = (EditText) findViewById(R.id.username2);
        new_password = (EditText) findViewById(R.id.password2);

        accountDatabaseHelper = new AccountDatabaseHelper(this);

        signInButton = (Button) findViewById(R.id.signin_button);
        signInButton.setOnClickListener(v -> {
            String username = existing_username.getText().toString();
            String password = existing_password.getText().toString();

            if(!username.equals("") && !password.equals("")) {
                if (accountDatabaseHelper.isValidLogin(username, password)) {
                    Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
            else {
                Toast.makeText(MainActivity.this, "Must provide username and password", Toast.LENGTH_SHORT).show();
            }
        });

        signUpButton = (Button) findViewById(R.id.signup_button);
        signUpButton.setOnClickListener(v -> {
            String username = new_username.getText().toString();
            String password = new_password.getText().toString();

            if(!username.equals("") && !password.equals("")){
                if(!accountDatabaseHelper.usernameExists(username)) {
                    if(accountDatabaseHelper.addUser(username, password)) {
                        new_username.setText("");
                        new_password.setText("");

                        Toast.makeText(MainActivity.this, "Signed up", Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(MainActivity.this, "Username already exists", Toast.LENGTH_SHORT).show();
                }
            }
            else {
                Toast.makeText(MainActivity.this, "Must provide username and password", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Method for adding new user credentials to the database
    public void newCred (){
        EditText user = (EditText)findViewById(R.id.username2);
        String username_content = user.getText().toString();

        EditText password = (EditText)findViewById(R.id.password2);
        String password_content = user.getText().toString();

        if(!(username_content.isEmpty() && password_content.isEmpty())){

        }
    }
}