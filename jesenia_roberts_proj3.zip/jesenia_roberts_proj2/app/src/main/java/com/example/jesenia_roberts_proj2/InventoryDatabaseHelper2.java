package com.example.jesenia_roberts_proj2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class InventoryDatabaseHelper2 extends SQLiteOpenHelper {

    public static final String database_file = "inventory2.db";

    public InventoryDatabaseHelper2(@Nullable Context context) {
        super(context, database_file, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create Table inventory(itemName TEXT primary key, quantity INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop Table if exists inventory");
    }

    public Boolean addItem(String item_name, int quantity) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("itemName", item_name);
        contentValues.put("quantity", quantity);
        long result = sqLiteDatabase.insert("inventory", null, contentValues);

        return result != -1;
    }

    public Boolean setQuantity(String item_name, int quantity) {
        if(quantity < 0) {
            quantity = 0;
        }

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("quantity", quantity);
        long result = sqLiteDatabase.update("inventory", contentValues, "itemName = ?", new String[]{item_name});

        return result != -1;
    }

    public void deleteItem(String item_name) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        sqLiteDatabase.delete("inventory", "itemName = ?", new String[]{item_name});
    }

    public Boolean itemExists(String item_name) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("Select * from inventory where itemName = ?", new String[]{item_name});

        return cursor.getCount() > 0;
    }
    public Cursor getItems(){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("Select * from inventory", new String[]{});

        return cursor;
    }
}
