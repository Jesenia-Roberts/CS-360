package com.example.jesenia_roberts_proj2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.widget.Button;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.GridLayout.LayoutParams;
import android.widget.ImageButton;
import android.database.Cursor;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    GridLayout grid_layout;
    TextView total_items;
    ImageButton notify;
    EditText add_item_name;
    EditText add_item_quantity;
    Button add_item_button;

    InventoryDatabaseHelper2 inventoryDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        inventoryDatabaseHelper = new InventoryDatabaseHelper2(this);

        grid_layout = (GridLayout) findViewById(R.id.gridLayout);

        total_items = (TextView) findViewById(R.id.totalItems);

        notify = (ImageButton) findViewById(R.id.notify);
        notify.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
            startActivity(intent);
        });


        add_item_name = (EditText) findViewById(R.id.item);
        add_item_quantity = (EditText) findViewById(R.id.quantity);
        add_item_button = (Button) findViewById(R.id.plus);
        add_item_button.setOnClickListener(v -> {
            String itemName = add_item_name.getText().toString();
            if(!inventoryDatabaseHelper.itemExists(itemName)) {
                int quantity;
                try {
                    quantity = Integer.parseInt(add_item_quantity.getText().toString());
                } catch (NumberFormatException e) {
                    quantity = -1;
                }

                if (!itemName.equals("") && quantity > 0) {
                    if (inventoryDatabaseHelper.addItem(itemName, quantity)) {
                        add_item_name.setText("");
                        add_item_quantity.setText("");
                        populateGrid();
                    } else {
                        Toast.makeText(MainActivity2.this, "Failed to add item", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MainActivity2.this, "Must provide item name and numeric quantity > 0", Toast.LENGTH_SHORT).show();
                }
            }
        });

        populateGrid();
    }

    public void populateGrid() {
        grid_layout.removeAllViews();

        Cursor cursor = inventoryDatabaseHelper.getItems();
        int rows = cursor.getCount();
        grid_layout.setRowCount(rows);
        total_items.setText("Items: " + rows);

        for(int i = 0; i < rows; i++) {
            if(cursor.moveToNext()) {
                final String item_name = cursor.getString(0);
                final int item_quantity = cursor.getInt(1);

                TextView name_view = new TextView(this);
                name_view.setText(item_name);
                name_view.setWidth(300);
                name_view.setHeight(72);
                name_view.setTextColor(Color.rgb(255, 255, 255));
                name_view.setTextSize(20);
                grid_layout.addView(name_view);

                TextView quantity_view = new TextView(this);
                quantity_view.setText("" + item_quantity);
                quantity_view.setWidth(48);
                quantity_view.setHeight(72);
                quantity_view.setTextColor(Color.rgb(255, 255, 255));
                quantity_view.setTextSize(20);
                grid_layout.addView(quantity_view);

                ImageButton left_arrow_button = new ImageButton(this);
                left_arrow_button.setBackgroundResource(R.drawable.left_arrow);
                left_arrow_button.setId(i);
                left_arrow_button.setOnClickListener(v -> {
                    inventoryDatabaseHelper.setQuantity(item_name, item_quantity - 1);
                    populateGrid();
                });
                grid_layout.addView(left_arrow_button);

                ImageButton right_arrow_button = new ImageButton(this);
                right_arrow_button.setBackgroundResource(R.drawable.right_arrow);
                right_arrow_button.setId(i + 1);
                right_arrow_button.setOnClickListener(v -> {
                    inventoryDatabaseHelper.setQuantity(item_name, item_quantity + 1);
                    populateGrid();
                });
                grid_layout.addView(right_arrow_button);

                ImageButton remove_circle_button = new ImageButton(this);
                remove_circle_button.setBackgroundResource(R.drawable.remove_circle);
                remove_circle_button.setId(i + 2);
                remove_circle_button.setOnClickListener(v -> {
                    inventoryDatabaseHelper.deleteItem(item_name);
                    populateGrid();
                });
                grid_layout.addView(remove_circle_button);
            }
        }

        grid_layout.refreshDrawableState();
    }

    public void addItem(){
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
    }
}